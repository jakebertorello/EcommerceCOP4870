using System;

namespace Maui.eCommerce.ViewModels
{
    public class MainViewModel
    {
        public string Display
        {
            get
            {
                return "Home";
            }
        }
    }
}